/*
 * Testcase to show lack of support for (System)Verilog attributes
 * in Questa's VPI implementation.
 *
 * Compile together with the SV file "attribs.sv".
 *
 * Jonathan Bromley, Verilab Ltd, 23 Nov 2013
 * jonathan.bromley@verilab.com +44-7713-241838
 */
 
#include <stdlib.h>
#include <veriuser.h>
#include <vpi_user.h>
#include <sv_vpi_user.h>

#ifdef _CPLUSPLUS
extern "C" {
#endif

/*
 * This function is called as a helper from the
 * main DPI entry point "explore_attributes".
 */
static void describe_variable(vpiHandle vh) {

  vpiHandle atr_iterator;
  vpiHandle atr_handle;
  char *var_name;

  var_name = vpi_get_str(vpiName, vh);
  
  if (vpi_get(vpiType, vh) != vpiIntVar) {

    io_printf("  Variable '%s' is not a vpiIntVar - ignoring it\n", var_name);

  } else {

    io_printf("  Describing vpiIntVar '%s'\n", var_name);
    atr_iterator = vpi_iterate(vpiAttribute, vh);
    if (atr_iterator == NULL) {
      io_printf("  vpi_iterate(vpiAttribute,...) returned NULL, nothing to do\n");
    } else {
      io_printf("  iterating over vpiAttribute[s]\n");
      while (1) {
        atr_handle = vpi_scan(atr_iterator);
        if (atr_handle == NULL) {
          io_printf("  No more attributes\n");
          break;
        } else {
          io_printf("    attribute '%s'\n", vpi_get_str(vpiName, atr_handle));
        }
      }
    }

  }
}


//---------------------------------------------------
// import "DPI-C" function void explore_attributes();
//---------------------------------------------------
extern void explore_attributes() {
  vpiHandle module_handle;
  vpiHandle var_iterator;
  vpiHandle var_handle;

  // Get handle to the top level module - we know this will work OK
  module_handle = vpi_handle_by_name("attribs", NULL);
  // Iterate over all variables
  var_iterator = vpi_iterate(vpiVariables, module_handle);
  if (var_iterator == NULL) {
    io_printf("vpi_iterate(vpiVariables,...) returned NULL, nothing to do\n");
  } else {
    io_printf("iterating over vpiVariables\n");
    while (1) {
      var_handle = vpi_scan(var_iterator);
      if (var_handle == NULL) {
        io_printf("No more variables\n");
        break;
      } else {
        describe_variable(var_handle);
      }
    }
  }
  
}

#ifdef _CPLUSPLUS
}
#endif
